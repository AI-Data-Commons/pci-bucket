'''
Beat Classification Global Variables
'''

from numpy.core.defchararray import index



SAMPLE_RATE = 360
NUMBER_OF_SUBJECTS = 48
SUBJECTS_EXCLUDED = [102, 104, 107, 217]
# SUBJECTS_EXCLUDED = [100, 102, 103, 104, 107, 114, 123, 124, 117]
SUBJECTS = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121,
            122, 123, 124, 200, 201, 202, 203, 205, 207, 208, 209, 210, 212, 213, 214, 215, 217, 219, 220, 221,
            222, 223, 228, 230, 231, 232, 233, 234]
SELECTED_SUBJECTS = [100, 101, 103, 105, 106, 108, 109, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121,
            122, 123, 124, 200, 201, 202, 203, 205, 207, 208, 209, 210, 212, 213, 214, 215, 219, 220, 221,
            222, 223, 228, 230, 231, 232, 233, 234]


DS1 = [101, 106, 108, 109, 112, 114, 115, 116, 118, 119, 122, 124, 201, 203, 205, 207, 208, 209, 215, 220, 223, 230]
DS2 = [100, 103, 105, 111, 113, 117, 121, 123, 200, 202, 210, 212, 213, 214, 219, 221, 222, 228, 231, 232, 233, 234]

TOTAL_BEATS = ['N', 'L', 'R', 'A', 'a', 'J', 'S', 'V', 'F', '[', '!', '[', 'e', 'j', 'E', '/', 'f', 'x', 'Q', '|']
TRUE_BEATS = ['N', 'L', 'R', 'e', 'j', 'A', 'a', 'J', 'S', 'V', 'E', 'F', '/', 'P', 'f', 'Q']
BEATS_CLASS = {'N':'N', 'L':'N', 'R':'N', 'e':'N', 'j':'N',
               'A':'S', 'a':'S', 'J':'S', 'S':'S',
               'V':'V', 'E':'V',
               'F':'F',
               '/':'Q', 'f':'Q', 'Q':'Q', 'P':'Q'}

ENCODER_TABLE = {'N': 0,'S': 1, 'V': 2, 'F': 3, 'Q': 4}
ENCODER_TABLE_v = {'N': 1,'S': 2, 'V': 3, 'F': 4, 'Q': 5}

PERF_MATRICS = ['accuracy','sensitivity', 'precision', 'specificity']




# ds1_indices = [SELECTED_SUBJECTS.index(x) for x in DS1]
# ds2_indices = [SELECTED_SUBJECTS.index(x) for x in DS2]
