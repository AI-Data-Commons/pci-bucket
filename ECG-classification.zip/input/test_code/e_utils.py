import os
import numpy as np
from scipy.signal import butter, lfilter, filtfilt, welch, resample
from sklearn.model_selection import train_test_split
from imblearn.under_sampling import RandomUnderSampler
import biosppy.signals.ecg as ecg
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from sklearn.utils import class_weight
from sklearn import preprocessing
import matplotlib.pyplot as plt
from collections import Counter
from config import *





def get_peaks(signal, fs):
    """
    This function uses biosppy module to detect R peaks in ECG signals
    :param signal: ECG segment
    :param fs: sampling frequency
    :return: R peaks, filtered ECG signal
    """
    #signal = butter_highpass_filter(signal, 1.0, 128.0)
    processed_signal = ecg.ecg(signal, fs, show=False)
    filtered_signal = processed_signal[1]
    r_peaks = processed_signal['rpeaks']
    return r_peaks, filtered_signal


def get_hrv(peaks, fs):
    """
    It computes the hearts rate variability series
    :param peaks: array of R peaks
    :param fs: sampling frequency
    :return: array of heart rate variability series
    """
    hrv_series = []
    total_peaks = len(peaks)
    peaks_count = 0
    while peaks_count < (total_peaks - 1):
        rr_interval = (peaks[peaks_count+1] - peaks[peaks_count])
        distance_ms = (float(rr_interval) / fs) * 1000.0
        # if 600 <= distance_ms <= 1300:
        #     hrv_series.append(distance_ms)
        hrv_series.append(distance_ms)
        peaks_count += 1
    return np.array(hrv_series)


def butter_highpass_filter(data, cutoff, fs, order=5):
    ''' Highpass filter '''
    def butter_highpass(cutoff, fs, order=5):
        nyq = 0.5 * fs
        normal_cutoff = cutoff / nyq
        b, a = butter(order, normal_cutoff, btype='high', analog=False)
        return b, a
    b, a = butter_highpass(cutoff, fs, order=order)
    y = filtfilt(b, a, data)
    return y


def butter_lowpass_filter(data, cutoff, fs, order=5):
    ''' Lowpass filter '''
    def butter_lowpass(cutoff, fs, order=5):
        nyq = 0.5 * fs
        normal_cutoff = cutoff / nyq
        b, a = butter(order, normal_cutoff, btype='low', analog=False)
        return b, a
    b, a = butter_lowpass(cutoff, fs, order=order)
    y = lfilter(b, a, data)
    return y


def re_annotations(labels, samples):
    """
    Get rid of the non-beats markers
    :param labels: Beats labels : (subjects x labels)
    :param samples: Beats indices : (subjects x indices)
    :return: Labels and samples ( of true beats)
    """
    beats_labels = []
    beats_indices = []
    # Declare beat types
    #   good = ['N', 'L', 'R', 'A', 'a', 'J', 'S', 'V', 'F', '[', '!', '[', 'e', 'j', 'E', '/', 'f', 'x', 'Q', '|']
    #   good = ['N', 'L', 'R', 'A', 'a', 'J', 'S', 'V', 'F', 'e', 'j', 'E', '/', 'f', 'Q']
    #   good = ['N', 'L', 'R', 'e', 'j', 'A', 'a', 'J', 'S', 'V', 'E', 'F', 'Q']
    for i in range(labels.shape[0]):
        sub_labels = labels[i]
        sub_samples = samples[i]
        ids = np.in1d(sub_labels, TRUE_BEATS)
        sub_labels = sub_labels[ids]
        sub_samples = sub_samples[ids]
        beats_labels.append(sub_labels)
        beats_indices.append(sub_samples)
    return np.array(labels), np.array(samples)



def encode_labels(x_train, y_train, x_test, y_test, beats_selected, experiment_type):

    ids1 = np.in1d(y_train, beats_selected)
    x_train = x_train[ids1, :]
    y_train = y_train[ids1]

    ids2 = np.in1d(y_test, beats_selected)
    x_test = x_test[ids2, :]
    y_test = y_test[ids2]

    if experiment_type == 'Normal Vs Abnormal':
        y_train = np.array([NABN_TABLE[v] for v in y_train])
        y_test = np.array([NABN_TABLE[v] for v in y_test])

    elif experiment_type == 'VEB Vs SVEB':
        print("Choose the right encoder")
        y_train = np.array([ENCODER_TABLE[v] for v in y_train])
        y_test = np.array([ENCODER_TABLE[v] for v in y_test])

    else:
        y_train = np.array([ENCODER_TABLE[v] for v in y_train])
        y_test = np.array([ENCODER_TABLE[v] for v in y_test])

    return x_train, y_train, x_test, y_test



def generate_tsne(activations):
    tsne = TSNE(n_components=2, init='random', n_iter=500)
    X_2d = tsne.fit_transform(np.array(activations))
    X_2d -= X_2d.min(axis=0)
    X_2d /= X_2d.max(axis=0)
    return X_2d


def beats_plot(total_beats, total_labels, segment_to_plot):
    """
    :param total_beats:
    :param total_labels:
    :param segment_to_plot:if channels=1 segment_to_plot=0.
                            if channels > 1
                            For previous segment: segment_to_plot=-1,
                            for next segement: segment_to_plot=1
    """

    for num, sub, in enumerate(SELECTED_SUBJECTS):
        if segment_to_plot==0:
            X = np.array(total_beats[num])
            Y = np.array(total_labels[num])
        elif segment_to_plot==-1:
            X = np.array(total_beats[num])
            Y = np.array(total_labels[num])
            X = X[:, :, 0]
        elif segment_to_plot==1:
            X = np.array(total_beats[num])
            Y = np.array(total_labels[num])
            X = X[:, :, 2]
        Y = np.array([ENCODER_TABLE[v] for v in Y])
        bnum = Counter(Y)
        uni_sym = list(bnum)
        sym_count = []
        for nu in uni_sym:
            sym_count.append(bnum[nu])
        uni_sym = [x for _, x in sorted(zip(sym_count, uni_sym))]
        sym_count = sorted(sym_count)
        sel_beats = []
        sel_labels = []
        for bt in uni_sym:
            xbeat = X[Y==bt]
            ybeat = Y[Y==bt]
            if len(ybeat) > 25 and bt != 0:
                xbeat = xbeat[:25, :]
                ybeat = ybeat[:25]
            sel_beats.extend(xbeat)
            sel_labels.extend(ybeat)
        sel_beats = np.array(sel_beats)
        sel_labels = np.array(sel_labels)
        sel_beats = sel_beats[:64, :]
        sel_labels = sel_labels[:64]
        plot_labels = ['N', 'S', 'V', 'F', 'Q']
        bcolors = ['green', 'red', 'blue', 'yellow', 'black']
        fig = plt.figure(1, figsize=(16, 12))
        for j in range(len(sel_labels)):
            plt.subplot(8, 8, j + 1)
            cl = bcolors[sel_labels[j]]
            plt.plot(sel_beats[j, :], color=cl, label=plot_labels[sel_labels[j]])
            plt.legend()


    # intervals feature extractions
    # Intervals_data = []
    # for index, (lbl, peak_index) in enumerate(zip(ecg_labels, ecg_samples)):
    #     seg_start = peak_index - left_bound
    #     seg_end = peak_index + right_bound
    #     if seg_start > 0 and seg_end < signal_end:
    #         beat = ecg_signal[seg_start:seg_end]
    #         #beat = resample(beat, 128)
    #         beats_data.append(beat)
    #         labels_data.append(BEATS_CLASS[TRUE_BEATS.index(lbl)])
    #         if index == 0:
    #             post_rr = (ecg_samples[index+1] - peak_index) / 360
    #             pre_rr = (ecg_samples[index+1] - peak_index) / 360
    #         elif index == len(ecg_samples)-1:
    #             post_rr = (peak_index - ecg_samples[index-1]) / 360
    #             pre_rr = (peak_index - ecg_samples[index-1]) / 360
    #         else:
    #             pre_rr = (peak_index - ecg_samples[index-1]) / 360
    #             post_rr = (ecg_samples[index+1] - peak_index) / 360
    #         Intervals_data.append([pre_rr, post_rr])
        plt.suptitle("ECG for subject: %s" % (sub))
        plt.savefig('MIT-BIH_Visualization/N128Beats/' + str(sub) + ".png")
        plt.close()

def visulaize_beats(X, Y):
    bnum = Counter(Y)
    uni_sym = list(bnum)
    sym_count = []
    for nu in uni_sym:
        sym_count.append(bnum[nu])
    uni_sym = [x for _, x in sorted(zip(sym_count, uni_sym))]
    sym_count = sorted(sym_count)
    sel_beats = []
    sel_labels = []
    for bt in uni_sym:
        xbeat = X[Y==bt]
        ybeat = Y[Y==bt]
        if len(ybeat) > 25 and bt != 0:
            xbeat = xbeat[:25, :]
            ybeat = ybeat[:25]
        sel_beats.extend(xbeat)
        sel_labels.extend(ybeat)
    sel_beats = np.array(sel_beats)
    sel_labels = np.array(sel_labels)
    print(sel_beats.shape, xbeat.shape)
    sel_beats = sel_beats[:64, 0, :]
    sel_labels = sel_labels[:64]
    print(sel_beats.shape, sel_labels.shape)
    plot_labels = ['N', 'S', 'V', 'F', 'Q']
    bcolors = ['green', 'red', 'blue', 'yellow', 'black']
    fig = plt.figure(1, figsize=(16, 12))
    for j in range(len(sel_labels)):
        plt.subplot(8, 8, j + 1)
        cl = bcolors[sel_labels[j]]
        plt.plot(sel_beats[j, :], color=cl, label=plot_labels[sel_labels[j]])
        plt.legend()
    plt.suptitle("ECG beats")
    plt.savefig('MIT-BIH_Visualization/test_data_mtb' + ".png")
    plt.close()

def feature_visualization(activations, y_fv, results_dir, num_classes):
    X_2d = generate_tsne(activations)
    print(X_2d.shape)
    # color_map = np.argmax(y_fv, axis=1)
    plt.figure(figsize=(8, 8))
    for cl in range(num_classes):
        act_indices = np.where(y_fv == cl)
        act_indices = act_indices[0]
        plt.scatter(x=X_2d[act_indices, 0], y=X_2d[act_indices, 1], label=cl)
    plt.legend()
    plt.savefig(os.path.join(results_dir, 'feature_visuals1.png'))


def beats_data_visualization(beats_data):
    ds1_indices = [SELECTED_SUBJECTS.index(x) for x in DS1]
    ds2_indices = [SELECTED_SUBJECTS.index(x) for x in DS2]
    ds1_data = beats_data[ds1_indices]
    ds2_data = beats_data[ds2_indices]

    plt.figure(figsize=(8, 8))
    for i in range(22):
        X_ds1 = generate_tsne(ds1_data[i])
        plt.scatter(x=X_ds1[:, 0], y=X_ds1[:, 1], label=i)
    plt.legend()
    plt.savefig('DS1_Raw_Data_Visualization4.png')
    plt.close()

    plt.figure(figsize=(8, 8))
    for i in range(22):
        X_ds2 = generate_tsne(ds2_data[i])
        plt.scatter(x=X_ds2[:, 0], y=X_ds2[:, 1], label=i)
    plt.legend()
    plt.savefig('DS2_Raw_Data_Visualization4.png')
    plt.close()

def beats_data_visualization_pca(beats_data):
    ds1_indices = [SELECTED_SUBJECTS.index(x) for x in DS1]
    ds2_indices = [SELECTED_SUBJECTS.index(x) for x in DS2]
    ds1_data = beats_data[ds1_indices]
    ds2_data = beats_data[ds2_indices]
    
    pca = PCA(n_components=2)
    colors = iter([plt.cm.tab20(i) for i in range(20)])
    plt.figure(figsize=(8, 8))
    for i in range(20):
        X_ds1 = pca.fit_transform(ds1_data[i])
        plt.scatter(x=X_ds1[:, 0], y=X_ds1[:, 1], c=[next(colors)], label=i, s=1.5)
    plt.legend()
    plt.savefig('DS1_Raw_Data_Visualization5.png')
    plt.close()

    colors2 = iter([plt.cm.tab20(i) for i in range(20)])
    plt.figure(figsize=(8, 8))
    for i in range(20):
        X_ds2 = pca.fit_transform(ds2_data[i])
        plt.scatter(x=X_ds2[:, 0], y=X_ds2[:, 1], c=[next(colors2)], label=i, s=1.5)
    plt.legend()
    plt.savefig('DS2_Raw_Data_Visualization5.png')
    plt.close()

def results_visualization(training_history, results_dir, metrics_names):
    """
    :param activations:
    :param training_history:
    :param y_fv:
    :param results_dir:
    :return:
    """

    plt.figure(figsize=(8, 6))
    plt.plot(training_history['Train']['loss'])
    plt.plot(training_history['Test']['loss'])
    plt.title('Model loss')
    plt.ylabel('Loss')
    plt.xlabel('Epoch')
    plt.legend(['train', 'test'], loc='upper left')
    plt.savefig(os.path.join(results_dir, 'loss_curve.png'))

    if 'accuracy' in metrics_names:
        plt.figure(figsize=(8, 6))
        plt.plot(training_history['Train']['accuracy'])
        plt.plot(training_history['Test']['accuracy'])
        plt.title('Model Accuracy')
        plt.ylabel('Accuracy')
        plt.xlabel('Epoch')
        plt.legend(['Train', 'Test'], loc='upper left')
        plt.savefig(os.path.join(results_dir, 'acc_curve.png'))

    if 'sensitivity' in metrics_names:
        plt.figure(figsize=(8, 6))
        plt.plot(training_history['Train']['sensitivity'])
        plt.plot(training_history['Test']['sensitivity'])
        plt.title('Model Sensitivity')
        plt.ylabel('Sensitivity')
        plt.xlabel('Epoch')
        plt.legend(['Train', 'Test'], loc='upper left')
        plt.savefig(os.path.join(results_dir, 'sensitivity_curve.png'))

    if 'specificity' in metrics_names:
        plt.figure(figsize=(8, 6))
        plt.plot(training_history['Train']['specificity'])
        plt.plot(training_history['Test']['specificity'])
        plt.title('Model Specificity')
        plt.ylabel('Specificity')
        plt.xlabel('Epoch')
        plt.legend(['Train', 'Test'], loc='upper left')
        plt.savefig(os.path.join(results_dir, 'specificity_curve.png'))

    if 'precision' in metrics_names:
        plt.figure(figsize=(8, 6))
        plt.plot(training_history['Train']['precision'])
        plt.plot(training_history['Test']['precision'])
        plt.title('Model Precision')
        plt.ylabel('Precision')
        plt.xlabel('Epoch')
        plt.legend(['Train', 'Test'], loc='upper left')
        plt.savefig(os.path.join(results_dir, 'precision_curve.png'))

    if 'f1_score' in metrics_names:
        plt.figure(figsize=(8, 6))
        plt.plot(training_history['Train']['f1_score'])
        plt.plot(training_history['Test']['f1_score'])
        plt.title('Model F1_Score')
        plt.ylabel('F1_Score')
        plt.xlabel('Epoch')
        plt.legend(['Train', 'Test'], loc='upper left')
        plt.savefig(os.path.join(results_dir, 'f1_score_curve.png'))

    if 'gm_score' in metrics_names:
        plt.figure(figsize=(8, 6))
        plt.plot(training_history['Train']['gm_score'])
        plt.plot(training_history['Test']['gm_score'])
        plt.title('Model Geometric Mean')
        plt.ylabel('Geometric Mean')
        plt.xlabel('Epoch')
        plt.legend(['Train', 'Test'], loc='upper left')
        plt.savefig(os.path.join(results_dir, 'gm_score_curve.png'))
    plt.close()

def get_confusionmatrix_readings(cm):
    FP = cm.sum(axis=0) - np.diag(cm)
    FN = cm.sum(axis=1) - np.diag(cm)
    TP = np.diag(cm)
    TN = cm.sum() - (FP + FN + TP)
    # Sensitivity, hit rate, recall, or true positive rate
    TPR = np.true_divide(TP, (TP + FN))
    # Specificity or true negative rate
    TNR = np.true_divide(TN, (TN + FP))
    # Precision or positive predictive value
    PPV = np.true_divide(TP, (TP + FP))

    # Overall accuracy
    ACC = np.true_divide((TP + TN), (TP + FP + FN + TN))
    # ACC_micro = (sum(TP) + sum(TN)) / (sum(TP) + sum(FP) + sum(FN) + sum(TN))
    print('Mean Accuracy is ', np.mean(ACC) * 100, sep=":")
    print('Mean Sensitivity is', np.mean(TPR) * 100, sep=":")
    print('Mean Specificity is', np.mean(TNR) * 100, sep=":")
    print('Mean Positive productivity is ', np.mean(PPV) * 100, sep=" : ")
    return [ACC, TPR, TNR, PPV]



def get_confusionmatrix_readings_new(cm):
    FP = cm.sum(axis=0) - np.diag(cm)
    FN = cm.sum(axis=1) - np.diag(cm)
    TP = np.diag(cm)
    TN = cm.sum() - (FP + FN + TP)

    ATN = TP[0]
    ATP = sum(TP[1:])
    AFN = cm.sum(axis=0)[0] - ATN
    AFP = cm.sum(axis=1)[0] - ATN
    
    cl_support = cm.sum(axis=1)
    total = sum(cl_support)
    # Sensitivity, hit rate, recall, or true positive rate
    TPR = np.true_divide(TP, (TP + FN))
    # Specificity or true negative rate
    TNR = np.true_divide(TN, (TN + FP))
    # Precision or positive predictive value
    PPV = np.true_divide(TP, (TP + FP))
    # Accuracy
    ACC = np.true_divide((TP + TN), (TP + TN + FP + FN))

    Mi_ACC = np.true_divide(sum(TP), total)
    We_ACC = np.true_divide (sum(ACC * cl_support), total)

    Mi_TPR = np.true_divide(sum(TP), sum(TP + FN))
    We_TPR = np.true_divide (sum(TPR * cl_support), total)

    Mi_TNR = np.true_divide(sum(TN), sum(TN + FP))
    We_TNR = np.true_divide (sum(TNR * cl_support), total)

    Mi_PPV = np.true_divide(sum(TP), sum(TP + FP))
    We_PPV = np.true_divide (sum(PPV * cl_support), total)
  
    Agg_ACC = np.true_divide(sum(TP), total)
    Agg_TPR = np.true_divide(ATP, (ATP + AFN))
    Agg_TNR = np.true_divide(ATN, cl_support[0])
    Agg_PPV = np.true_divide(ATP, (ATP + AFP))
    

    class_perf = np.round([ACC * 100, TPR * 100, TNR * 100, PPV * 100], 2)
    macro_perf = np.round([np.mean(ACC) * 100, np.mean(TPR) * 100, np.mean(TNR) * 100, np.mean(PPV) * 100], 2)
    micro_perf = np.round([Mi_ACC * 100, Mi_TPR * 100, Mi_TNR * 100, Mi_PPV * 100], 2)
    we_perf = np.round ([We_ACC * 100, We_TPR * 100, We_TNR * 100, We_PPV * 100], 2)
    agg_perf = np.round([Agg_ACC * 100, Agg_TPR * 100, Agg_TNR * 100, Agg_PPV * 100], 2)

    print('Class\t  Acc\t  Sen\t  Spe\t  +Pr')
    print('{}\t {}\t {}\t {}\t {}'.format(
            'macro', macro_perf[0], macro_perf[1], macro_perf[2], macro_perf[3]))
    print('{}\t {}\t {}\t {}\t {}'.format(
            'micro', micro_perf[0], micro_perf[1], micro_perf[2], micro_perf[3]))
    print('{}\t {}\t {}\t {}\t {}'.format(
            'weight', we_perf[0], we_perf[1], we_perf[2], we_perf[3]))
    print('{}\t {}\t {}\t {}\t {}'.format(
            'aggre', agg_perf[0], agg_perf[1], agg_perf[2], agg_perf[3]))
   

    perf_dict = {'perclass': class_perf,
              'Macro': macro_perf,
              'Micro': micro_perf,
              'Weighted': we_perf,
              'Aggregate': agg_perf}

    return perf_dict


def save_results(ARGS, results, result_dir):
    classes = ARGS.beats
    with open(os.path.join(result_dir, 'C.txt'), 'w') as fp:
        print(ARGS, file=fp)
        print(results[4], file=fp)
        print(' ', file=fp)
        fp.write('Class\tAccuracy\tSensitivity\tSpecificity\tPositive productivity\n')
        for i in range(len(classes)):
            fp.write('{}\t{}\t{}\t{}\t{}\n'.format(
                classes[i], results[0][i], results[1][i], results[2][i], results[3][i]))
        print(' ', file=fp)
        print('Mean Accuracy is ', np.mean(results[0]) * 100, sep=":", file=fp)
        print('Mean Sensitivity is', np.mean(results[1]) * 100, sep=":", file=fp)
        print('Mean Specificity is', np.mean(results[2]) * 100, sep=":", file=fp)
        print('Mean Positive productivity is ', np.mean(results[3]) * 100, sep=" : ", file=fp)
        print(' ', file=fp)
        print(results[5], file=fp)
        print(' ', file=fp)
        fp.close()

def save_results_new(ARGS, results, result_dir):
    result_dir = 'test_result/'
    classes = ARGS.beats
    with open(os.path.join(result_dir, 'Results.txt'), 'w') as fp:
        #print(ARGS, file=fp)
        #print('Parameters', file=fp)
        #fp.write('Parameters              \t  Values\n')
        for key, value in vars(ARGS).items():
            fp.write('{}                  \t{}\n'.format(key, value))
        print('Confusion Matrix', file=fp)
        print(results['Con_mat'], file=fp)
        print(' ', file=fp)
        cl_results = results['perclass']
        ma_results = results['Macro']
        mi_results = results['Micro']
        we_results = results['Weighted']
        ag_results = results['Aggregate']

        fp.write('Class\t  Acc\t  Sen\t  Spe\t  +Pr\n')
        for i in range(len(classes)):
            fp.write('  {}\t {}\t {}\t {}\t {}\n'.format(
                classes[i], cl_results[0][i], cl_results[1][i], cl_results[2][i], cl_results[3][i]))
        print(' ', file=fp)
        fp.write('  {}\t {}\t {}\t {}\t {}\n'.format(
                'macro', ma_results[0], ma_results[1], ma_results[2], ma_results[3]))
        print(' ', file=fp)
        fp.write('  {}\t {}\t {}\t {}\t {}\n'.format(
                'micro', mi_results[0], mi_results[1], mi_results[2], mi_results[3]))
        print(' ', file=fp)
        fp.write('  {}\t {}\t {}\t {}\t {}\n'.format(
                'weighted', we_results[0], we_results[1], we_results[2], we_results[3]))
        print(' ', file=fp)
        fp.write('  {}\t {}\t {}\t {}\t {}\n'.format(
                'aggregate', ag_results[0], ag_results[1], ag_results[2], ag_results[3]))
        print(' ', file=fp)
        print(results['report'], file=fp)
        print(' ', file=fp)
        fp.close()

