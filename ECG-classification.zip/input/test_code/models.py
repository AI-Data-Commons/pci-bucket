import torch
import numpy as np
import torchvision
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import torch.nn.functional as F
from torchinfo import summary


class feat_att(nn.Module):
    def __init__(self):
        super(feat_att, self).__init__()

        self.attconv1 = nn.Conv1d(1,1,kernel_size=1, stride=1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        atout = torch.mean(x, dim=2, keepdim=False)
        atout = torch.reshape(atout, (atout.shape[0], 1, atout.shape[1]))
        t_out = self.attconv1(atout)
        mask = self.sigmoid(t_out)
        mask = torch.reshape(mask, (mask.shape[0], mask.shape[2],  mask.shape[1]))
        t_out = x * mask
        return t_out



class block_one(nn.Module):
    def __init__(self, input_kernel, output_kernel, kernel_size, act, dp_state, dp_rate, padding):
        super(block_one,self).__init__()
        self.dp_state = dp_state


        self.conv = nn.Conv1d(input_kernel, output_kernel, kernel_size=kernel_size, 
                                stride=1, padding=padding, padding_mode='replicate')
        self.batch_norm = nn.BatchNorm1d(output_kernel)

        if act == 'relu':
            self.activation = nn.ReLU()
        if act == 'prelu':
            self.activation = nn.PReLU()

        if self.dp_state:
            self.dropout = nn.Dropout(p=dp_rate)

        self.max_pool1 = nn.MaxPool1d(kernel_size=2, stride=2)

    def forward(self,x):
        if self.dp_state:
            return self.max_pool1(self.dropout(self.activation(self.batch_norm(self.conv(x)))))
        else:
            return self.max_pool1(self.activation(self.batch_norm(self.conv(x))))



class block_two(nn.Module):
    def __init__(self, input_kernel, output_kernel, kernel_size, act, dp_rate, padding):
        super(block_two,self).__init__()
        
        self.conv1 = nn.Conv1d(input_kernel, output_kernel, kernel_size=kernel_size, 
                                stride=1, padding=padding, padding_mode='replicate')

        self.batch_norm1 = nn.BatchNorm1d(output_kernel)

        if act == 'prelu':
            self.activation1 = nn.PReLU()
        else:
            self.activation1 = nn.ReLU()

        self.dropout1 = nn.Dropout(p=dp_rate)

        self.conv2 = nn.Conv1d(output_kernel, output_kernel, kernel_size=kernel_size, 
                                stride=1, padding=padding, padding_mode='replicate')

        self.batch_norm2 = nn.BatchNorm1d(output_kernel)

        if act == 'prelu':
            self.activation2 = nn.PReLU()
        else:
            self.activation2 = nn.ReLU()

        self.dropout2 = nn.Dropout(p=dp_rate)

        self.conv3 = nn.Conv1d(input_kernel, output_kernel, kernel_size=1, 
                                stride=1, padding=padding, padding_mode='replicate')

    def forward(self,x):
        residual = x
        out = self.conv1(x)
        out = self.batch_norm1(out)
        out = self.activation1(out)
        out = self.dropout1(out)

        out = self.conv2(out)
        out = self.batch_norm2(out)
        residual = self.conv3(residual)
        out = out + residual
        out = self.activation2(out)
        out = self.dropout2(out)

        return out 




class base_v1(nn.Module):
    def __init__(self,num_classes, input_kernel, output_kernel, kernel_size, act, padding):
        super(base_v1,self).__init__()
        self.num_classes = num_classes

        self.b1_1 = block_one(1, output_kernel, kernel_size, act, True, 0.0, padding)
        self.b2_1 = block_two(output_kernel, 64, kernel_size, act, 0.5, padding)
        self.b2_2 = block_two(64, 128, kernel_size, act, 0.5, padding)
        self.pooling1 = nn.MaxPool1d(kernel_size=2, stride=2, padding=0)
        self.att_1 = feat_att()

        self.flatten = nn.Flatten()
        self.fc3 = nn.Linear(5760, self.num_classes)

    def forward(self, x):

        x = self.b1_1(x)
        x = self.b2_1(x)
        x = self.b2_2(x)
        
        x = self.pooling1(x)
        x = self.att_1(x)
        x = self.flatten(x)
        logits = self.flatten(x)

        logits = self.fc3(x)
        output = F.softmax(logits, dim=1)
        return logits, output



class base_v2(nn.Module):
    def __init__(self,num_classes, input_kernel, output_kernel, kernel_size, act, padding):
        super(base_v2,self).__init__()
        self.num_classes = num_classes

        self.b1_1 = block_one(1, output_kernel, kernel_size, act, True, 0.0, padding)
        self.b2_1 = block_two(output_kernel, 64, kernel_size, act, 0.5, padding)
        self.b2_2 = block_two(64, 128, kernel_size, act, 0.5, padding)
        self.b2_3 = block_two(128, 256, kernel_size, act, 0.5, padding)
        self.pooling1 = nn.MaxPool1d(kernel_size=2, stride=2, padding=0)
        self.att_1 = feat_att()

        self.flatten = nn.Flatten()
        self.fc3 = nn.Linear(11520, self.num_classes)

    def forward(self, x):

        x = self.b1_1(x)
        x = self.b2_1(x)
        x = self.b2_2(x)
        x = self.b2_3(x)
        x = self.pooling1(x)

        x = self.att_1(x)
        x = self.flatten(x)
        logits = self.fc3(x)
        output = F.softmax(logits, dim=1)
        return logits, output

class base_v3(nn.Module):
    def __init__(self,num_classes, input_kernel, output_kernel, kernel_size, act, padding):
        super(base_v3,self).__init__()
        self.num_classes = num_classes

        self.b1_1 = block_one(1, output_kernel, kernel_size, act, True, 0.0, padding)
        self.att_1 = feat_att()

        self.b2_1 = block_two(output_kernel, 64, kernel_size, act, 0.5, padding)
        self.b2_2 = block_two(64, 128, kernel_size, act, 0.5, padding)
        self.b2_3 = block_two(128, 256, kernel_size, act, 0.5, padding)
        self.pooling1 = nn.MaxPool1d(kernel_size=2, stride=2, padding=0)
        self.att_2 = feat_att()


        self.flatten = nn.Flatten()
        self.fc3 = nn.Linear(11520, self.num_classes)

    def forward(self, x):

        x = self.b1_1(x)
        x = self.att_1(x)
        x = self.b2_1(x)
        x = self.b2_2(x)
        x = self.b2_3(x)
        #x = self.b2_4(x)
        x = self.pooling1(x)

        x = self.att_2(x)

        x = self.flatten(x)

        logits = self.fc3(x)
        output = F.softmax(logits, dim=1)
        return logits, output





def init_weight(m):
    if isinstance(m, nn.Conv1d):
        torch.nn.init.kaiming_normal_(m.weight.data)

    if isinstance(m, nn.Linear):
        torch.nn.init.kaiming_normal_(m.weight.data)




def get_model(num_classes, input_kernel, output_kernel, kernel_size, act, padding, model_num):
    if model_num==1:
        model = base_v1(num_classes, input_kernel, output_kernel, kernel_size, act, padding)

    if model_num==2:
        model = base_v2(num_classes, input_kernel, output_kernel, kernel_size, act, padding)

    if model_num==3:
        model = base_v3(num_classes, input_kernel, output_kernel, kernel_size, act, padding)

    model.apply(init_weight)

    return model


# model = get_model(5, input_kernel=32, output_kernel=32, kernel_size=15, act='relu', padding='same', model_num=7).to('cuda')
# #model = feat_att().to('cuda')
# result = summary(model, 
#                 input_size=(1, 1, 180), 
#                 #input_size=(1, 128, 45), 
#                 verbose = 1,
#                 col_width=16,
#                 col_names=["input_size", "output_size", "kernel_size", "mult_adds"])
