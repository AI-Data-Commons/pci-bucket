import argparse
import os
import sys
import pickle
import shutil
import numpy as np
import random
import torch
import json
import sklearn.metrics as sklm
from sklearn import metrics
from sklearn.metrics import accuracy_score
from imblearn.metrics import specificity_score
import models
import e_utils

def parse_args():
    parser = argparse.ArgumentParser(description='Evaluation of Arrhythmia detection model')
    parser.add_argument('--seed', default = 8, help='seed')

    # Data parameters
    parser.add_argument('--fs', default=360, type=int, help='sampling_frequency')
    parser.add_argument('--seg', default=280, type=int, help='Segment length')
    parser.add_argument('--data_dir', default='input/testset/', type=str, help='Testdata directory path')

    # Experiment parameters
    parser.add_argument('--beats', default=['N', 'S', 'V', 'F', 'Q'], help='Selected beats')
    parser.add_argument('--beatslbl', default=['N', 'S', 'V', 'F', 'Q'], help='Selected beats')

    # Evaluation parameters
    parser.add_argument('--test_batch', default=1000, type=int, help='batch size')
    parser.add_argument('--net_g', default='input/best_model/best_accmodel.pt', type=str, help='pretrained best model')

    # Model parameters
    parser.add_argument('--ksize', default=15, help='kernel size')
    parser.add_argument('--model_num', default=1, help='model version')
    parser.add_argument('--act', default='prelu', choices=['relu', 'prelu'], help='actuvaton type')
    #parser.add_argument('--net_g', default='input/pre_trained_model/trained_model.pth', type=str, help='pretrained model')

    return parser.parse_args()

class Logger(object):
    def __init__(self, trial_path):
        #trial_stamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        logdir = os.path.join(trial_path)
        if not os.path.exists(logdir):
            os.mkdir(logdir)
        if len(os.listdir(logdir)) != 0:
            ans = input("log_dir is not empty. All data inside log_dir will be deleted. "
                            "Will you proceed [y/N]? ")
            if ans in ['y', 'Y']:
                shutil.rmtree(logdir)
            else:
                exit(1)
        self.set_dir(logdir)

    def set_dir(self, logdir, log_fn='log.txt'):
        self.logdir = logdir
        if not os.path.exists(logdir):
            os.mkdir(logdir)
        self.log_file = open(os.path.join(logdir, log_fn), 'a')

    def log(self, string):
        self.log_file.write('[%s] %s' % (datetime.now(), string) + '\n')
        self.log_file.flush()

        print('[%s] %s' % (datetime.now(), string))
        sys.stdout.flush()

    def log_dirname(self, string):
        self.log_file.write('%s (%s)' % (string, self.logdir) + '\n')
        self.log_file.flush()

        print('%s (%s)' % (string, self.logdir))
        sys.stdout.flush()


# performance metrics
def compute_matrics(y_true, y_pred):
    accuracy = sklm.accuracy_score(y_true, y_pred)
    recall = sklm.recall_score(y_true, y_pred, average='macro', zero_division=0)
    precision = sklm.precision_score(y_true, y_pred, average='macro', zero_division=0)
    specificity = specificity_score(y_true, y_pred, average='macro')
    f1score = sklm.f1_score(y_true, y_pred, average='macro', zero_division=0)

    metrics_values = np.array([accuracy, recall, precision, specificity, f1score])
    return metrics_values


# load test data
def load_dataset(file_path):
    database =  pickle.load(open(os.path.join(file_path, "MIT-BIH_test_data.p"), 'rb'))
    return database



def model_evaluation(model, device, data, target, LOGDIR, ARGS):
    model.eval()
    with torch.no_grad():
        data, target = torch.from_numpy(data).to(device), torch.from_numpy(target).to(device)
        logits, output = model(data)
        true_labels = target.cpu().detach().numpy()
        pred_labels = output.cpu().detach().numpy()
        pred_labels = np.argmax(pred_labels, axis=1)

    eval_matrics = compute_matrics(true_labels, pred_labels)                  
    cm = metrics.confusion_matrix(y_true=true_labels, y_pred=pred_labels)
    results = e_utils.get_confusionmatrix_readings_new(cm)
    class_report = metrics.classification_report(y_true=true_labels, y_pred=pred_labels)
    print(class_report)
    results['Con_mat'] = cm
    results['report'] = class_report
    e_utils.save_results_new(ARGS, results, LOGDIR)

 


def eval_model():
    ARGS = parse_args()
    random.seed(ARGS.seed)     
    np.random.seed(ARGS.seed)  

    base_dir = os.path.join('input', 'best_model')
    if not os.path.exists(base_dir):
            os.mkdir(base_dir)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    training_data = load_dataset(ARGS.data_dir)

    x_test = training_data['x_test']
    y_test = training_data['y_test'] 

    ckpt_g = ARGS.net_g
#print(len(['N', 'S', 'V', 'F', 'Q']), input_kernel=32, output_kernel=32, kernel_size=15, act='prelu', padding='same', model_num=1)
#    num_classes, input_kernel, output_kernel, kernel_size, act, padding, model_num


    #model = models.get_model(5, 32, 32, 15,'prelu', 'same', 1)
    model = models.get_model(len(ARGS.beats), input_kernel=32, output_kernel=32, kernel_size=ARGS.ksize, act=ARGS.act, padding='same', model_num=2).to(device)
    model.load_state_dict(torch.load(ckpt_g)['state_dict'])

    #model = torch.load(ckpt_g)

    model_evaluation(model, device, x_test, y_test, base_dir, ARGS)

    
    # #torch.save({'epoch': epoch,
    #         'state_dict': model.state_dict(),
    #         'optimizer_state_dict':optimizer.state_dict(),
    #         'loss': [avg_train_loss, avg_test_loss],
    #         'matrics': [training_matrics, test_matrics]
    #         }, LOG_best_accmodel)
    #         best_acc = test_matrics[0]




if __name__ == "__main__":

    eval_model()
    


